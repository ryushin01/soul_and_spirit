// 파일 업로드 갯수
export const FILE_MAXIMUM_NUMBER: number = 20;

// 파일 업로드 용량 (20MB)
export const FILE_MAXIMUM_SIZE: number = 1024 ** 2 * 20;

export const FILE_MAXIMUM_SIZE_STRING: string = "20MB";
