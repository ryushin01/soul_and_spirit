// 정적 파일 정상 유무 확인
export const PUBLIC_FILES_REG_EXP = /\.(.*)$/;