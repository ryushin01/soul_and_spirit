export default async function Lawyer() {
  return (
    <>법무대리인</>
  );
}
