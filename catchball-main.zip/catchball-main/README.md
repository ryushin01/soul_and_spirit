1. 윌슨 A2000 클레이튼 커쇼 GM
<img width="777" alt="image" src="https://github.com/ryushin01/ro/assets/141554987/94dd6355-5665-41ae-b61f-eb08abd4c14a">

- 정보
    - 투수 글러브
    - 11.75인치 크기
    - 근본 색상!


* * *


2. 윌슨 A2000 1787SC
<img width="714" alt="image" src="https://github.com/ryushin01/ro/assets/141554987/d89f8a4d-0816-4e3d-8a3c-50b9050f3a25">

- 정보
    - 내야수 글러브
    - 11.75인치 크기
    - 공의 회전을 급격히 줄이는 기능 탑재


* * *


3. 윌슨 A2000 DP15
<img width="682" alt="image" src="https://github.com/ryushin01/ro/assets/141554987/f5a0b8ac-4252-4d14-9cfb-50ab5bebcf11">

- 정보
    - 내야수 글러브
    - 11.5인치 크기
    - 손이 작다면 추천!
